// {
//     "description":"В случае если поле Comment содержит строку 'Response:' извлекает текст следующий после ':' и парсит его как JSON строку, после чего извлекает из полученного обьекта список банкнот и сумму платежа, а также считает общую сумму по всем найденным платежам"  
// }
()=>{
	let dict = window.appg.ddConnector.DictObject
	let commentFld = dict.CurrentLogRow.Comment;
	let searchCriteria = "Response:";
	let jsonStr = commentFld.substring(commentFld.indexOf(searchCriteria)+searchCriteria.length);
	let parseResult = JSON.parse(jsonStr);
	let banknotesList = parseResult.result.obj.paymentBanknotes;
	let currReportItem = {banknotes:banknotesList.map(itm=>{return {encashmentGuid:itm.encashmentGuid,paymentGuid:itm.paymentGuid,banknoteGuid:itm.banknoteGuid,faceValue:itm.faceValue}}),sum:parseResult.result.obj.amountPayment};
	if(!dict.PaymentReport){
		dict.PaymentReport = {payments:[],total:0};		
	}
	dict.PaymentReport.payments.push(currReportItem);
	dict.PaymentReport.total += currReportItem.sum;		
	return "OK";
}