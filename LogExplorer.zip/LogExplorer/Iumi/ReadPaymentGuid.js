// {
//     "description":"В случае если поле Comment содержит строку 'Response:' извлекает текст следующий после ':' и парсит его как JSON строку, после чего извлекает из полученного обьекта свойство CurrentPaymentGuid и записывает его в window.appg.ddConnector.DictObject"  
// }
()=>{
	let dict = window.appg.ddConnector.DictObject
	let commentFld = dict.CurrentLogRow.Comment;
	let searchCriteria = "Response:";
	let jsonStr = commentFld.substring(commentFld.indexOf(searchCriteria)+searchCriteria.length);
	let resultObj = JSON.parse(jsonStr);
	dict.CurrentPaymentGuid = resultObj.result.CurrentPaymentGuid;
	return "OK";
}