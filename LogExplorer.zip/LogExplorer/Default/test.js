// {
//     "Description":"Testing action"
// }
()=>{
	let dict = window.appg.ddConnector.DictObject
	let commentFld = dict.CurrentLogRow.Comment;
	let searchCriteria = "Response:";
	let jsonStr = commentFld.substring(commentFld.indexOf(searchCriteria)+searchCriteria.length);
	let resultObj = JSON.parse(jsonStr);
	dict.CurrentPaymentGuid = resultObj.result.CurrentPaymentGuid;
	return "OK";
}